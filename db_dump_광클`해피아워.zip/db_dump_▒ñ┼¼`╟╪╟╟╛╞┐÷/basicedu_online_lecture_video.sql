-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: stam.iptime.org    Database: basicedu
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `online_lecture_video`
--

DROP TABLE IF EXISTS `online_lecture_video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `online_lecture_video` (
  `VIDEO_NO` int(11) NOT NULL AUTO_INCREMENT COMMENT '강의영상번호',
  `ONLINE_LECTURE_NO` int(11) NOT NULL COMMENT '온라인강의번호',
  `CHAPTER_NO` varchar(8) NOT NULL COMMENT '챕터번호',
  `VIDEO_NAME` varchar(128) NOT NULL COMMENT '강의영상명',
  `VIDEO_INFO` varchar(4000) DEFAULT NULL COMMENT '강의영상설명',
  `VIDEO_FILE` varchar(128) NOT NULL COMMENT '영상파일명',
  `REGISTER_DATE` datetime NOT NULL COMMENT '등록일시',
  `VIDEO_FILE_ORG` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`VIDEO_NO`),
  KEY `FK_ONLINE_LECTURE_VIDEO` (`ONLINE_LECTURE_NO`),
  CONSTRAINT `FK_ONLINE_LECTURE_VIDEO` FOREIGN KEY (`ONLINE_LECTURE_NO`) REFERENCES `online_lecture` (`ONLINE_LECTURE_NO`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `online_lecture_video`
--

LOCK TABLES `online_lecture_video` WRITE;
/*!40000 ALTER TABLE `online_lecture_video` DISABLE KEYS */;
INSERT INTO `online_lecture_video` VALUES (18,20,'1','감성 스타일리스트가 알려주는 영상 촬영','수동 모드 촬영 노하우와 간단한 편집 기술을 활용하여\r\n총 4개의 작품 만들기','a7bc2e067dcb485ea15a040da653581b.mp4','2020-12-24 14:00:39','test_video.mp4'),(19,21,'1','기초 준비하기: 도형과 3면룸','아이소메트릭 작업 환경 세팅과 파일 만들고 저장하기','6ab4fbcff84e4353b5eed22528f9fd64.mp4','2020-12-24 14:03:38','test_video.mp4'),(20,22,'1','Welcome웰컴! 어서오세요!','프로크리에이트의 기본','6924d4d5c9da4e01a14234925ddb2e9a.mp4','2020-12-24 14:07:01','test_video.mp4'),(22,24,'1','웹 개발 기본 지식','웹 개발 기본 지식','70e5e7a1923c4f6b9407b618591a4608.mp4','2020-12-24 14:20:40','test_video.mp4'),(26,29,'1','3단 캔들 만들기','캔들조색에 필요한 재료 보기','d70b04e26ecc40c596d8a28e287c2180.mp4','2020-12-28 09:20:08','test_video.mp4'),(30,33,'1','기타를 치려면 반드시 필요한 지판화성학!','기타인생에서의 터닝포인트!\r\n모든 키는 똑같다! 조표 상관없이 어떤 키든 OK!\r\n지판화성학 기타에서는 뭘 배우는 건가요?','4b6f957d4351498d85cd5b1e4dcccaef.mp4','2020-12-29 09:25:39','test_video.mp4'),(35,47,'1','재료와 드레싱의 꿀조합 레시피','재료와 드레싱의 꿀조합 레시피','b4b9ee912bac4037ab44dedad62ed861.mp4','2020-12-29 14:53:32','test_video.mp4'),(36,51,'1','타로의 시작','타로의 시작','726404fabc524520a6f9415d7a21ef2a.mp4','2020-12-29 15:15:46','test_video.mp4'),(83,67,'1','믿고보는 유잰의 \'색다른컬러\'클래스입니다.','안녕하세요, 유잰입니다.\r\n걱정마세요. 타고난 컬러감각? 그런 거 없어도 됩니다.','54ec8e31891c406993b178d4c252a5bc.mp4','2020-12-31 10:44:20','test_video.mp4'),(84,67,'2','\'색알못\'인 나...이대로 괜찮을까요?','유난히 쓰던 색만 쓰게 되는 이유,\r\n색에 대한 나의 느낌 꺼내보기\r\n나의 컬러 친밀도 그리고 현주소','c5119a93f01141588bd423696c522452.mp4','2020-12-31 10:44:20','test_video.mp4'),(85,67,'3','기초는 아무리 배워도 과함이 없다.','색의 속성-1 색상\r\n색의 속성-2 채도\r\n색의 속성-3 명도\r\n색체계(Color System)','761a98f49e7c4edaa29ce495e29159af.mp4','2020-12-31 10:44:20','test_video.mp4');
/*!40000 ALTER TABLE `online_lecture_video` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-19 16:43:02

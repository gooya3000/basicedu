-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: stam.iptime.org    Database: basicedu
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hh_user`
--

DROP TABLE IF EXISTS `hh_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hh_user` (
  `ORIGIN_NUM` bigint(20) NOT NULL AUTO_INCREMENT,
  `ID` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `PASSWORD` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `NAME` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `ADDRESS` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `ADDRESS_DT` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `TEL` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `EMAIL` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `AGREE1` int(1) DEFAULT '0' COMMENT '개인정보활용 동의',
  `AGREE2` int(1) DEFAULT '0' COMMENT '마케팅수신 동의',
  `USER_DT` int(2) DEFAULT '1' COMMENT '일반사용자: 1 / 스토어사용자: 2 / 휴먼 계정: 3 / 탈퇴회원: 4 /  관리자: 9',
  `EMAIL_IDT` int(1) DEFAULT '0' COMMENT '미인증: 0 / 인증: 1',
  `POSTCODE` varchar(7) DEFAULT NULL COMMENT '우편번호',
  `JDATE` datetime DEFAULT NULL,
  PRIMARY KEY (`ORIGIN_NUM`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hh_user`
--

LOCK TABLES `hh_user` WRITE;
/*!40000 ALTER TABLE `hh_user` DISABLE KEYS */;
INSERT INTO `hh_user` VALUES (18,'test14','9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08','test','서울 노원구 노원로 398 (상계동)','test','01055556666','test2@test',1,1,1,1,'01705',NULL),(20,'ttttt','37c9aa3186e19d9e3cfb4f2ec195d3a3ba27e280be967bda536828003c94a0d2','test','서울 강남구 삼성로 11 (개포동, 디에이치아너힐즈)','tt','010-0000-00','test@test',1,0,4,0,'06327',NULL),(21,'test23','9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08','ddddd','서울 강남구 가로수길 9 (신사동)','test999999999','999','test@naver.com',1,1,1,1,'06035',NULL),(22,'test1','9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08','test','서울 강남구 가로수길 5 (신사동)','test11','01052316709','111@nnn.com',1,0,9,1,'06035','2021-08-10 17:36:36'),(24,'test2','03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4','테스트','서울 강남구 삼성로 11 (개포동, 디에이치아너힐즈)','테스트','01000000000','bluedmoel@icloud.com',1,1,2,1,'06327',NULL),(25,'ttest','a1bd1312d23002be258c9bb4642bbea77580353869a8ee8844e6940b7e0278b7','test222','제주특별자치도 제주시 한경면 낙천리 1648-1','11111112호','01010100101','znsl69@naver.com',1,0,1,1,'63004',NULL),(26,'test55555','03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4','test','서울 강남구 봉은사로 403 (삼성동)','test','01050000000','cheonej96@naver.com',1,0,1,1,'06097',NULL),(27,'test1010','7a5df5ffa0dec2228d90b8d0a0f1b0767b748b0a41314c123075b8289e4e053f','김해피','서울 금천구 서부샛길 528 (가산동)','111','01052316709','withardor0923@naver.com',1,0,2,1,'08505',NULL),(28,'124test','9042331956e30c2779cdeefcd339336d1c78ec55e565419bbe8b48716f4ba247','test','서울 강남구 봉은사로 403 (삼성동)','ttt','01000050055','cheonej94@naver.com',1,1,1,0,'06097',NULL),(29,'test1456','7e2b3635331e128005813ef974e4dec888aa2306ad6b3c55d84b2c21e6c4850b','test','서울 강남구 봉은사로 403 (삼성동)','test','01055556666','test2@test',1,1,1,0,'06097','2021-08-12 15:10:45'),(30,'cheonej95','94be5921c87b1c07fd04b0e57ec5fe79c2c2c53e255bf832de2cb770c73ebf00','천은지','인천 부평구 대정로90번길 7 (부평동)','301호','01050367952','cheonej95@naver.com',1,1,1,1,'21395','2021-08-27 10:57:07'),(34,'test1992','6d4c560cf80f7b59b4494c1e96d727ddf9187e7598fff3fab59d9340b3e148a2','홍길동','서울 금천구 서부샛길 528 (가산동)','1111','01050367952','withdud0923@stam.kr',1,0,1,1,'08505','2021-11-12 15:09:19');
/*!40000 ALTER TABLE `hh_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-19 16:43:01

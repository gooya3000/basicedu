-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: stam.iptime.org    Database: basicedu
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hh_comment`
--

DROP TABLE IF EXISTS `hh_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hh_comment` (
  `CNUM` int(11) NOT NULL AUTO_INCREMENT,
  `NUM` int(11) NOT NULL,
  `CREFER` int(11) NOT NULL,
  `CLEVEL` int(11) NOT NULL,
  `CSUNBUN` int(11) NOT NULL,
  `NAME` varchar(30) NOT NULL,
  `ID` varchar(30) DEFAULT NULL,
  `CCONTENT` varchar(1000) DEFAULT NULL,
  `WDATE` datetime NOT NULL,
  `UPDATE_DATE` datetime DEFAULT NULL,
  `CEXIST` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`CNUM`),
  KEY `hh_board_fk` (`NUM`),
  CONSTRAINT `hh_board_fk` FOREIGN KEY (`NUM`) REFERENCES `hh_board` (`NUM`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hh_comment`
--

LOCK TABLES `hh_comment` WRITE;
/*!40000 ALTER TABLE `hh_comment` DISABLE KEYS */;
INSERT INTO `hh_comment` VALUES (1,1,1,0,0,'','','test','2021-07-27 17:40:45',NULL,'N'),(2,1,2,0,0,'','','댓글 !!!!!!!!!!!!!!!!!!','2021-07-27 17:40:54',NULL,'N'),(3,3,3,0,0,'','','test','2021-07-28 09:44:20',NULL,'N'),(5,3,5,0,0,'test','test1','test','2021-07-28 09:46:13',NULL,'N'),(12,3,12,0,0,'','','댓글 33333','2021-07-28 16:22:01',NULL,'N'),(13,3,13,0,0,'test','test1','test2233','2021-07-28 14:11:12','2021-07-28 14:01:08','N'),(17,1,17,0,0,'test','test1','test','2021-07-28 10:04:30',NULL,'N'),(18,1,18,0,0,'','','test','2021-07-28 10:04:32',NULL,'N'),(19,27,19,0,0,'test','test1','test','2021-07-28 10:08:44',NULL,'N'),(20,27,20,0,0,'','','test','2021-07-28 10:08:46',NULL,'N'),(21,1,21,0,0,'test','test1','test111 댓글','2021-07-28 10:15:23',NULL,'N'),(22,1,22,0,0,'','','test 222 댓글','2021-07-28 10:15:30',NULL,'N'),(23,27,23,0,0,'test','test1','댓글 test','2021-07-28 10:18:40',NULL,'N'),(24,27,24,0,0,'test','test1','댓글 test 22','2021-07-28 10:18:46',NULL,'N'),(25,3,25,0,0,'테스트','test2','test ttt ','2021-07-28 16:21:12',NULL,'N'),(26,1,26,0,0,'test','test1','test','2021-07-29 13:55:34',NULL,'N'),(27,2,27,0,0,'test','test1','test','2021-07-29 13:56:04',NULL,'N'),(28,3,28,0,0,'test','test1','test','2021-07-29 13:59:05',NULL,'N'),(29,3,29,0,0,'test','test1','test','2021-07-29 14:03:23',NULL,'N'),(30,2,30,0,0,'test','test1','ttttt','2021-08-02 17:23:47',NULL,'N'),(31,31,31,0,0,'test','test1','yyyy','2021-08-09 11:55:14',NULL,'N'),(32,31,32,0,0,'','','test','2021-08-10 14:13:41',NULL,'N'),(33,33,33,0,0,'test','test1','test','2021-08-13 11:08:30',NULL,'N'),(34,33,34,0,0,'test','test1','','2021-08-13 11:08:31',NULL,'N'),(35,33,35,0,0,'test','test1','test','2021-08-13 11:09:13',NULL,'N'),(36,33,36,0,0,'test','test1','','2021-08-13 11:37:22',NULL,'N'),(37,45,37,0,0,'test','test14','test222','2021-08-23 17:59:00',NULL,'N'),(38,45,38,0,0,'test','test14','test\n','2021-08-23 18:06:46',NULL,'N'),(39,45,39,0,0,'test','test14','test','2021-08-23 18:06:47',NULL,'N'),(40,45,40,0,0,'test','test14','test','2021-08-23 18:06:48',NULL,'N'),(41,45,41,0,0,'test','test14','test','2021-08-23 18:06:49',NULL,'N'),(42,45,42,0,0,'test','test1','testtttt','2021-08-23 18:09:21',NULL,'N'),(43,45,43,0,0,'test','test1','testtttt','2021-08-23 18:09:24',NULL,'N'),(44,43,44,0,0,'천은지','cheonej95','test','2021-08-27 11:06:39',NULL,'N'),(45,43,45,0,0,'천은지','cheonej95','ttest','2021-08-27 11:06:45',NULL,'N'),(46,46,46,0,0,'천은지','cheonej95','test\n','2021-08-27 11:07:43',NULL,'N'),(47,46,47,0,0,'천은지','cheonej95','test11','2021-08-27 12:03:03',NULL,'N'),(48,46,48,0,0,'천은지','cheonej95','testtt','2021-08-27 12:03:31',NULL,'N'),(49,45,49,0,0,'천은지','cheonej95','test','2021-08-27 12:14:34',NULL,'Y'),(50,43,50,0,0,'천은지','cheonej95','test1111','2021-08-27 12:15:27',NULL,'Y');
/*!40000 ALTER TABLE `hh_comment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-19 16:43:02

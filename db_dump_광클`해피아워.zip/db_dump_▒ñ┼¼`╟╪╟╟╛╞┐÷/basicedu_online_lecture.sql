-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: stam.iptime.org    Database: basicedu
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `online_lecture`
--

DROP TABLE IF EXISTS `online_lecture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `online_lecture` (
  `ONLINE_LECTURE_NO` int(11) NOT NULL AUTO_INCREMENT COMMENT '온라인강의번호',
  `LECTURER_ID` varchar(128) DEFAULT NULL COMMENT '강사ID',
  `ONLINE_LECTURE_NAME` varchar(128) DEFAULT NULL COMMENT '온라인강의명',
  `ONLINE_LECTURE_INFO` varchar(4000) NOT NULL COMMENT '온라인강의소개',
  `IMG_FILE` varchar(128) DEFAULT NULL COMMENT '대표사진',
  `PRICE` int(11) DEFAULT NULL COMMENT '가격',
  `LIBRARY_FILE_ORG` varchar(128) DEFAULT NULL,
  `LIBRARY_FILE_STR` varchar(128) DEFAULT NULL,
  `REGISTER_DATE` datetime DEFAULT NULL COMMENT '등록일시',
  PRIMARY KEY (`ONLINE_LECTURE_NO`),
  KEY `FK_ONLINE_LECTURE_LECTURER_ID_MEMBER_ID` (`LECTURER_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `online_lecture`
--

LOCK TABLES `online_lecture` WRITE;
/*!40000 ALTER TABLE `online_lecture` DISABLE KEYS */;
INSERT INTO `online_lecture` VALUES (20,'soyoung1','감성 스타일리스트가 알려주는 영상 촬영, 연출, 그리고 편집','입문자분들을 위한\r\n영상 촬영, 스타일링, 그리고 편집\r\n클래스입니다.','36ea6d7d7d484e85a760d32938148f62.jpg',15000,'upload_sample.txt','0a746a46ba8347a89503cc3861c73c2a.txt','2020-12-24 14:00:39'),(21,'soyoung1','공간 안에 그려내는 새로운 시점, 아이소메트릭 디자인','초급자분들을 위한 아이소메트릭 일러스트 클래스입니다.','ba0eac505a864f2c944b338571a43646.png',50000,'upload_sample.txt','0d0c826e207943e5ab91c56ae87592a2.txt','2020-12-24 14:03:38'),(22,'soyoung1','아이패드 드로잉 기초부터 굿즈 제작','아이패드와 프로크리에이트를 이용해\r\n총 8개의 작품 만들기','5bf4dd7405c0417281de297a76c3ffc6.gif',16000,'upload_sample.txt','e6290712926b47789cabdb415bd37d77.txt','2020-12-24 14:07:01'),(24,'testtest1','한큐 프로의 JAVA 웹 개발자     양성 과정','입문자분들을 위한 풀 스택 웹 개발자 취업 준비 과정\r\n클래스입니다.','a0c3334e0b6147488bfba46004dced9e.jpg',16000,'upload_sample.txt','5be62535dd4640e4b9aee22c508b6f6d.txt','2020-12-24 14:20:40'),(29,'testtest1','센트보틀의 일상에 선물이 되는 향기 만들기','재료의 준비 부터 작품 제작까지 모두 알아볼 거예요!\r\n이 클래스를 통해 캔들 제작과정의 즐거움을 느껴요!\r\n동시에 캔들 재료의 올바른 이해와 캔들과 방향제류의 올바른 사용법도 알려드려요.','4cea6a6d3cee4f109b8d53688f178bb7.jpg',50000,'upload_sample.txt','9fb871e870574228b210df4c9eb7806f.txt','2020-12-28 09:20:08'),(33,'soyoung1','기타의 네비게이션, 지판화성학! 쉽고 재미있게 정복하자','지판화성학(코드 3가지 모형과 스케일) 총 5개의 작품 만들기','e3d08d71ac454d66a3687b576d1ea11b.jpg',99990,'upload_sample.txt','427e34cb032640da87410c8c8e5f7c8d.txt','2020-12-29 09:25:39'),(47,'soyoung2','샐러드만으로 맛과 양 모두 즐기는 샐러드 레시피','다양한 샐러드 토핑을 이용해 총 13개의 작품 만들기','3dd26748098a4514b909fdce92df5320.jpg',34900,'upload_sample.txt','ae074150add345fda872e1e31bf4267c.txt','2020-12-29 14:53:32'),(51,'soyoung2','이봄의 타로 클래스 ❥ 고민으로 잠 못드는 당신을 위해','입문자분들을 위한 타로 클래스입니다.','094bc8aae4ad4d9189b5c2113f8f34f6.png',39500,'upload_sample.txt','557aad6afba34be0b612aa99f4b89e13.txt','2020-12-29 15:15:46'),(67,'soyoung2','색다른컬러연구소 유잰에게 배우는 배색 노하우!','초급자분들을 위한 배색 공식과 색 추출법 클래스입니다.\r\n배색 수업은 컬러리스트에게만 필요한 것이 아닙니다. 그래픽 디자인을 하는 작업자, 보고서를 작성해야 하는 직장인, 패션에 관심이 많아 센스 있게 옷을 입고 싶은 분들께도 도움을 드릴 수 있어요.','b593618be40d4be18623a9d7a632cd69.jpg',125000,NULL,NULL,'2020-12-31 10:44:20');
/*!40000 ALTER TABLE `online_lecture` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-19 16:43:02

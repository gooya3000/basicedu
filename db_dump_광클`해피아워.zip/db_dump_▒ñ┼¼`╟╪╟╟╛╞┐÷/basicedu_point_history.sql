-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: stam.iptime.org    Database: basicedu
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `point_history`
--

DROP TABLE IF EXISTS `point_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `point_history` (
  `HISTORY_NO` int(11) NOT NULL AUTO_INCREMENT COMMENT '이력번호',
  `ID` varchar(128) NOT NULL COMMENT '회원ID',
  `CONTENTS` varchar(256) NOT NULL COMMENT '내용',
  `POINT` int(11) NOT NULL COMMENT '포인트',
  PRIMARY KEY (`HISTORY_NO`),
  KEY `FK_POINT_HISTORY_ID_MEMBER_ID` (`ID`),
  CONSTRAINT `FK_POINT_HISTORY_ID_MEMBER_ID` FOREIGN KEY (`ID`) REFERENCES `member_info` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COMMENT='포인트이력';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `point_history`
--

LOCK TABLES `point_history` WRITE;
/*!40000 ALTER TABLE `point_history` DISABLE KEYS */;
INSERT INTO `point_history` VALUES (1,'test1','스토어 상품 구매',-1000),(2,'test3','스토어 상품 구매',-500),(3,'test1','포인트 환급(온라인강의 완료) +1500P',1500),(5,'test3','스토어 상품 구매',-500),(8,'soyoung','포인트 환급(온라인강의 완료) +1500P',1500),(9,'soyoung','포인트 사용(온라인강의 구매) -1500P',0),(10,'soyoung','포인트 환급(온라인강의 완료) +1500P',1500),(11,'soyoung','포인트 사용(온라인강의 구매) -500P',-500),(12,'soyoung','포인트 환급(온라인강의 완료) +1500P',1500),(13,'test1','포인트 환급(온라인강의 완료) +1600P',1600),(14,'testtest1','포인트 환급(온라인강의 완료) +1600P',1600),(15,'testtest1','포인트 사용(온라인강의 구매) -600P',-600),(16,'soyoung','포인트 사용(온라인강의 구매) -500P',500),(17,'soyoung','포인트 사용(온라인강의 구매) -300P',-200),(18,'soyoung','포인트 사용(온라인강의 구매) -100P',-100),(19,'soyoung','포인트 사용(온라인강의 구매) -100P',-100),(20,'soyoung','포인트 환급(온라인강의 완료) +1600P',1600),(21,'soyoung','포인트 환급(온라인강의 완료) +1600P',1600),(22,'stam1201','포인트 환급(온라인클래스 수강 완료)',9999),(23,'stam1201','포인트 환급(온라인클래스 수강 완료)',1500),(24,'stam1201','포인트 환급(온라인클래스 수강 완료)',3950),(25,'testtest1','포인트 환급(온라인클래스 수강 완료)',5000),(26,'testtest1','포인트 사용(온라인클래스 구매)',-1000);
/*!40000 ALTER TABLE `point_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-19 16:43:03

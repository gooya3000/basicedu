-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: stam.iptime.org    Database: basicedu
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hh_store`
--

DROP TABLE IF EXISTS `hh_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hh_store` (
  `IDX` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'PK 인덱스',
  `ORIGIN` bigint(20) DEFAULT NULL COMMENT 'FK USER테이블 참조',
  `STORE_NM` varchar(100) DEFAULT NULL,
  `STORE_TEL` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `STORE_ADDRESS` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `STORE_ADDRESS_DT` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `HIT_COUNT` bigint(20) DEFAULT NULL,
  `STORE_IDT` int(2) DEFAULT NULL COMMENT '1 한식 / 2 분식 / 3 중식 / 4 패스트푸드 / 5 양식 / 6 카페디저트 / 7 일식',
  `STORE_IMG` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '스토어 대표 이미지',
  `STORE_INFO` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '스토어 소개',
  `REGIST_DATE` datetime DEFAULT NULL,
  `REGIST_ID` varchar(30) DEFAULT NULL,
  `UPDATE_DATE` datetime DEFAULT NULL,
  `UPDATE_ID` varchar(30) DEFAULT NULL,
  `STORE_IMG_OID` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `LONGITUDE` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '경도',
  `LATITUDE` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '위도',
  `STORE_POINT` point DEFAULT NULL COMMENT '좌표 포인트',
  `STORE_OPEN` varchar(10) DEFAULT NULL COMMENT '영업시간-오픈',
  `STORE_CLOSE` varchar(10) DEFAULT NULL COMMENT '영업시간-마감',
  `STORE_BREAK` int(1) DEFAULT NULL COMMENT '브레이크타임 없음 0 / 있음 1',
  `BREAK_START` varchar(10) DEFAULT NULL COMMENT '브레이크 시작',
  `BREAK_END` varchar(10) DEFAULT NULL COMMENT '브레이크 끝',
  `LINE_YN` int(1) DEFAULT '1' COMMENT '줄서기 이용 1 / 미사용 0',
  `RSV_YN` int(1) DEFAULT '1' COMMENT '예약 이용 1 / 미사용 0',
  `LINE_NOTICE` varchar(100) DEFAULT NULL COMMENT '줄서기 미사용 공지',
  `RSV_NOTICE` varchar(100) DEFAULT NULL COMMENT '예약 미사용 공지',
  `HOLIDAY` varchar(100) DEFAULT NULL COMMENT '정기휴일',
  `HOLIDAY_ETC` varchar(100) DEFAULT NULL COMMENT '기타휴일',
  `STORE_USE` int(1) DEFAULT '1' COMMENT '운영여부 운영1 / 미운영 0',
  PRIMARY KEY (`IDX`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hh_store`
--

LOCK TABLES `hh_store` WRITE;
/*!40000 ALTER TABLE `hh_store` DISABLE KEYS */;
INSERT INTO `hh_store` VALUES (12,27,'육회로운연어생활','0211112222','08391|서울 구로구 구로동 1124-38','1층',10,1,'banner3.jpg','육회로운연어생활\r\n영업시간은 코로나격상 시 정부지침에 따릅니다.','2021-07-28 10:22:41','test999','2021-08-11 16:11:14','test1010','SF210728102241522200.jpg','126.900722153293','37.4840139425125',_binary '\0\0\0\0\0\0\0Fˇn��_@�:+��B@','10:00','04:00',0,'10:00','04:00',1,0,'테스트111','1234','2`4`','',1),(13,0,'홍콩반점0410 가산대륭점','0211334455','08510|서울 금천구 벚꽃로 298 (가산동)','102호',8,3,'korean-food-jajangmyeon-noodle-with-fermented-black-beans-sauce.jpg','주문마감은 21:50입니다.','2021-07-28 10:29:19','test999','2021-07-28 10:29:19','test999','SF210728102919534586.jpg','126.883871693415','37.4814401689835',_binary '\0\0\0\0\0\0\0�D�Z��_@\�a\�ԟ�B@','11:00','22:00',1,'15:00','16:00',1,1,NULL,NULL,NULL,NULL,1),(14,27,'샐러디SALADY','0212345678','08503|서울 금천구 가산디지털1로 181 (가산동)','106호',16,5,'banner1.jpg','*일요일 휴무\r\n*토요일 및 공휴일은 08:00~17:00까지 영업합니다.','2021-07-28 10:33:00','test999','2021-07-29 14:12:11',NULL,'SF210728103300974862.jpg','126.880393604209','37.4814249861909',_binary '\0\0\0\0\0\0\0\�kj^X�_@f�}U��B@','07:00','21:30',1,'15:00','16:30',1,1,NULL,NULL,NULL,NULL,1),(15,27,'스쿨푸드 마리오아울렛점','0233334444','08511|서울 금천구 디지털로9길 23 (가산동)','마리오아울렛 3관 12층',1,2,'korean-instant-noodle-tteokbokki-korean-spicy-sauce-ancient-food.jpg','누구나 좋아하는 분식을 지키고 먹는이에 대한 사랑과 정성이 가득 담긴 음식을 만들어가는 스쿨푸드입니다.','2021-07-28 10:49:37','test999','2021-07-28 10:49:37','test999','SF210728104936792374.jpg','126.886476789522','37.478720573213',_binary '\0\0\0\0\0\0\0?\�$	��_@�\�:�F�B@','11:00','21:00',0,NULL,NULL,1,1,NULL,NULL,NULL,NULL,1),(16,27,'노브랜드버거 가산디지털단지점','0233663366','08511|서울 금천구 벚꽃로 286 (가산동)','1층',24,4,'burger-1553287_1920.jpg','NoBrand Burger!\r\n가성비 좋은 가격으로 푸짐하고 독자적인 감칠맛나는 서양식 패스트 캐주얼 음식을 제공합니다.','2021-07-28 11:00:04','test999','2021-07-28 11:00:04','test999','SF210728110004724479.jpg','126.884121140151','37.4803938924495',_binary '\0\0\0\0\0\0\0��\�p��_@f��}�B@','10:00','22:00',0,NULL,NULL,1,1,NULL,NULL,NULL,NULL,1),(17,27,'코애식당','0211119999','08505|서울 금천구 가산디지털2로 127-33 (가산동)','가산대명벨리온 1층 103호',204,8,'rice-noodle.jpg','베트남 조리사 분들이 오랜 호텔 경력을 가지고 있습니다.','2021-07-28 11:06:24','test999','2021-08-11 17:33:42','test1010','SF210728110650451978.jpg','126.877791132027','37.4783834911311',_binary '\0\0\0\0\0\0\0�1ۺ-�_@\\���;�B@','11:00','21:00',0,'11:00','21:00',1,1,NULL,NULL,'4`5`1`','',1),(18,27,'브릭스피자BricksPizza','0331111111','24287|강원 춘천시 서부대성로 255 (효자동)','2층',36,5,'pizza-pizza-filled-with-tomatoes-salami-olives.jpg','매주 월요일 휴무','2021-07-28 11:29:46',NULL,'2021-08-11 15:21:24','test1010','SF210728112946237035.jpg','127.746379338483','37.8724144053405',_binary '\0\0\0\0\0\0\0tLح\�\�_@��uF�\�B@','12:00','23:30',0,'12:00','23:30',1,1,NULL,NULL,'1`2`3`','',1);
/*!40000 ALTER TABLE `hh_store` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-19 16:43:00

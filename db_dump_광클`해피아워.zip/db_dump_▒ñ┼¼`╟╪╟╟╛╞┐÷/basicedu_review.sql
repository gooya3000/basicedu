-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: stam.iptime.org    Database: basicedu
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
  `REVIEW_NO` int(11) NOT NULL AUTO_INCREMENT COMMENT '후기번호',
  `ID` varchar(128) DEFAULT NULL COMMENT '회원ID',
  `KEY_NO` int(11) DEFAULT NULL COMMENT '주문번호/강의번호',
  `KEY_SECTION` varchar(3) DEFAULT NULL COMMENT '상품/강의 구분(OFF:오프라인강의 ON:온라인강의 P:상품)',
  `CONTENTS` varchar(4000) DEFAULT NULL COMMENT '내용',
  `REGISTER_DATE` datetime DEFAULT NULL COMMENT '등록일자',
  PRIMARY KEY (`REVIEW_NO`),
  KEY `FK_REVIEW_PRODUCT_NO_PRODUCT_PRODUCT_NO` (`KEY_NO`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (8,'test1',35,'off','asdf1231','2020-12-17 09:58:01'),(9,'test1',35,'off','asdasdㅇㄹㄴㅇㄹㄴㅇㄹ','2020-12-17 10:23:46'),(12,'test1',4,'P','구매후기 테스트\r\n11\r\n22\r\n33','2020-12-17 13:30:49'),(14,'test1',5,'P','테스트상품 구매후기\r\n1\r\n2\r\n3\r\n4','2020-12-17 14:42:15'),(23,'test2',35,'off','test\n1\n2\n3\n4\n5','2020-12-24 10:00:24'),(28,'testtest1',26,'on','좋은 강의 감사합니다','2020-12-24 15:30:26'),(30,'test1',24,'on','강의후기 테스트!!!','2020-12-24 15:41:09'),(31,'testtest1',24,'on','좋은 강의\r\n정말 감사합니다.','2020-12-28 14:16:19'),(33,'test1',42,'off','1111\n2222\n3333\n4444','2020-12-28 16:50:26'),(34,'soyoung',20,'on','재미있네요','2020-12-29 10:47:53'),(35,'test4',44,'P','구매후기!!!\r\n테스트\r\n테스트!!','2020-12-29 14:47:12'),(36,'stam1201',33,'on','후기입니다','2020-12-29 16:17:19'),(41,'testtest1',67,'on','후기 후기 후기','2021-01-01 18:10:33'),(42,'testtest1',21,'on','dddddddddd','2021-01-01 21:19:14');
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-19 16:43:01

-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: stam.iptime.org    Database: basicedu
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hh_board`
--

DROP TABLE IF EXISTS `hh_board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hh_board` (
  `TITLE` varchar(200) NOT NULL,
  `CONTENT` varchar(4000) NOT NULL,
  `REGISTER_DAY` datetime DEFAULT NULL,
  `FILENAME` varchar(200) DEFAULT NULL,
  `ORIGIN_FILENAME` varchar(200) DEFAULT NULL,
  `CATEGORY` int(10) DEFAULT NULL,
  `HITS` int(5) DEFAULT '0',
  `ORIGIN` bigint(20) DEFAULT NULL,
  `NUM` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `FILENAME2` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `ORIGIN_FILENAME2` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `ID` varchar(30) NOT NULL,
  `REFER` int(10) DEFAULT NULL,
  `LEVEL` int(10) DEFAULT NULL,
  `SUNBUN` int(10) DEFAULT NULL,
  `EXIST` varchar(10) DEFAULT NULL,
  `USER_DT` int(2) DEFAULT NULL,
  PRIMARY KEY (`NUM`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hh_board`
--

LOCK TABLES `hh_board` WRITE;
/*!40000 ALTER TABLE `hh_board` DISABLE KEYS */;
INSERT INTO `hh_board` VALUES ('test','test','2021-07-27 17:36:36','de98b001-a81b-4eff-b32b-6637f0c298b1_0708_업무_천은지.txt','0708_업무_천은지.txt',1,29,0,1,'test','67bb39b2-b4c8-46ae-97d5-9d4964bdbe74_1. 손익분석 기초자료.xlsx','1. 손익분석 기초자료.xlsx','test1',1,0,0,'Y',NULL),('test111','test','2021-07-27 17:41:47',NULL,NULL,1,30,0,2,'test',NULL,NULL,'test1',2,0,0,'Y',NULL),('test','test ','2021-07-27 17:43:58','ce59155a-f590-4579-b7b7-fd2e22e70c71_1. 손익분석 기초자료.xlsx','1. 손익분석 기초자료.xlsx',1,193,0,3,'test','875f0d4b-c00d-4a60-84f6-ebe7e21d4fb4_test1.jpg','test1.jpg','test1',3,0,0,'Y',NULL),('[RE]test','test','2021-07-28 09:44:36',NULL,NULL,1,21,0,27,'test',NULL,NULL,'test1',1,1,1,'N',NULL),('[RE]test111','ttt','2021-07-29 18:11:00',NULL,NULL,1,2,0,28,'test',NULL,NULL,'test1',2,1,1,'Y',NULL),('test','test','2021-07-29 18:11:09',NULL,NULL,1,56,0,29,'test',NULL,NULL,'test1',29,0,0,'N',NULL),('test','ttt','2021-08-02 16:02:21','29233164-2f39-4502-ba8b-cbd78e1f0dab_test1.jpg','test1.jpg',1,75,0,30,'test',NULL,NULL,'test1',30,0,0,'Y',NULL),('test YYY','YYY','2021-08-09 11:55:08','9b1f01a0-4152-42fc-87d6-5b8c8b7ba751_bms수정건.png','bms수정건.png',1,32,0,31,'test',NULL,NULL,'test1',31,0,0,'Y',NULL),('글 삭제 테스트','test','2021-08-09 13:54:54','560babf6-fa50-4d22-b1f9-1f0c00d46657_test1.jpg','test1.jpg',1,6,0,32,'ddddd',NULL,NULL,'test23',32,0,0,'N',NULL),('test1255','tes555','2021-08-11 10:40:39','bfb21a33-4fad-42bd-acf1-6a63b582ddd2_test2.jpg','test2.jpg',1,29,0,33,'test',NULL,NULL,'test1',33,0,0,'Y',NULL),('test','test','2021-08-13 15:10:41','7d10ea83-45fe-4500-bcc0-668dcaad0cd7_test1.jpg','test1.jpg',1,2,0,34,'test',NULL,NULL,'test1',34,0,0,'Y',NULL),('tttt','ttt','2021-08-13 15:14:14','461c0776-dc54-4825-a820-5b7f2a47368f_test2.jpg','test2.jpg',1,1,0,35,'test',NULL,NULL,'test1',35,0,0,'Y',NULL),('tesstt','test','2021-08-13 16:16:45',NULL,NULL,1,1,0,36,'test',NULL,NULL,'test1',36,0,0,'Y',9),('test','tttt','2021-08-13 16:16:50',NULL,NULL,1,0,0,37,'test',NULL,NULL,'test1',37,0,0,'Y',9),('ttt','ttt','2021-08-13 16:16:51',NULL,NULL,1,3,0,38,'test',NULL,NULL,'test1',38,0,0,'Y',9),('[RE]test','rrrtt','2021-08-13 16:23:13',NULL,NULL,1,1,0,39,'test',NULL,NULL,'test1',34,1,1,'Y',NULL),('test','112','2021-08-23 15:31:18',NULL,NULL,1,0,0,40,'test',NULL,NULL,'test1',40,0,0,'Y',9),('test','2222','2021-08-23 15:31:31',NULL,NULL,1,0,0,41,'test',NULL,NULL,'test1',41,0,0,'Y',9),('[RE]tttt','test','2021-08-23 17:49:50',NULL,NULL,1,0,0,42,'test',NULL,NULL,'test1',35,1,1,'Y',NULL),('공지사항 test','test','2021-08-23 17:51:02',NULL,NULL,0,18,0,43,'test',NULL,NULL,'test1',43,0,0,'Y',9),('test','tttt','2021-08-23 17:51:13',NULL,NULL,1,0,0,44,'test',NULL,NULL,'test1',44,0,0,'Y',9),('test','tttest','2021-08-23 17:54:49',NULL,NULL,1,15,0,45,'test',NULL,NULL,'test14',45,0,0,'Y',1),('테스트','테스트 ','2021-08-27 11:07:22','f9cd0aa9-8ab4-4c21-aff0-15c78a9a07c1_test1.jpg','test1.jpg',1,8,0,46,'천은지',NULL,NULL,'cheonej95',46,0,0,'Y',1),('[RE]공지사항 test test test ','testttt','2021-08-27 12:16:05','207795d0-af32-4e93-97b9-41a57df98f3e_test2.jpg','test2.jpg',1,1,0,47,'천은지',NULL,NULL,'cheonej95',43,1,1,'N',NULL),('[RE]ttttttttttttttttttt','test','2021-08-27 12:16:26',NULL,NULL,1,1,0,48,'천은지',NULL,NULL,'cheonej95',38,1,1,'Y',NULL),('test111','test','2021-11-12 15:21:46','088a99c7-4d9c-4e27-90a5-647cabac4c83_PPT첨부파일테스트.pptx','PPT첨부파일테스트.pptx',1,0,0,49,'김해피',NULL,NULL,'test1010',49,0,0,'Y',2),('test공지','test','2021-11-12 15:22:44',NULL,NULL,0,7,0,50,'test',NULL,NULL,'test1',50,0,0,'Y',9);
/*!40000 ALTER TABLE `hh_board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-19 16:43:00

-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: stam.iptime.org    Database: basicedu
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `offline_lecture`
--

DROP TABLE IF EXISTS `offline_lecture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `offline_lecture` (
  `OFFLINE_LECTURE_NO` int(11) NOT NULL AUTO_INCREMENT COMMENT '오프라인강의번호',
  `OFFLINE_LECTURE_NAME` varchar(300) DEFAULT NULL COMMENT '오프라인강의이름',
  `OFFLINE_LECTURE_INTRODUCE` varchar(3000) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '오프라인강의소개',
  `OFFLINE_LECTURE_IMG` varchar(300) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '오프라인강의이미지',
  `OFFLINE_LECTURE_ADDRESS` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '오프라인강의주소',
  `OFFLINE_LECTURE_MIN` int(11) DEFAULT NULL COMMENT '오프라인강의 최소인원',
  `OFFLINE_LECTURE_MAX` int(11) DEFAULT NULL COMMENT '오프라인강의최대인원',
  `OFFLINE_LECTURE_APPLYPERIODSTART` date DEFAULT NULL COMMENT '오프라인강의신청기간',
  `OFFLINE_LECTURE_SCHEDULE` date DEFAULT NULL COMMENT '오프라인강의 일정',
  `OFFLINE_LECTURE_REG` datetime DEFAULT NULL COMMENT '오프라인강의 등록일시',
  `ID` varchar(128) DEFAULT NULL COMMENT '회원아이디',
  `OFFLINE_LECTURE_APPLYPERIODEND` date NOT NULL,
  PRIMARY KEY (`OFFLINE_LECTURE_NO`),
  KEY `FK_OFFLINE_LECTURE_ID_MEMBER_ID` (`ID`),
  CONSTRAINT `FK_OFFLINE_LECTURE_ID_MEMBER_ID` FOREIGN KEY (`ID`) REFERENCES `member_info` (`ID`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offline_lecture`
--

LOCK TABLES `offline_lecture` WRITE;
/*!40000 ALTER TABLE `offline_lecture` DISABLE KEYS */;
INSERT INTO `offline_lecture` VALUES (34,'[1:1_청담샵 경력] ❤ 강남역오픈❤ 자존감이 두배 올라가는 메이크업!','메이크업의 고민을 적어주시면 그에 맞춰서 커리큘럼이 재구성 됩니다!\r\n실제로 만나뵙고 수강생님의 첫 인상, 억양, 성격, 전체적인 분위기를 보며 방향성을 잡고 있습니다^^\r\n선호하는 메이크업 스타일과 다른거 같아서 걱정이시라고요?!\r\n걱정 마세요 ! 나만의 메이크업 스타일을 찾아드립니다!\r\n내눈에도 예쁘고 남에 눈에도 예쁘게 보이는 메이크업 기술을 알려드릴게요!','20201224172640_청담샵.PNG','인천광역시 남동구 서창남순환로 9 (서창동, 이편한세상서창)',10,10,'2020-12-22','2020-12-31','2020-12-29 15:47:43','test2','2020-12-30'),(36,'[원데이영상편집1위/기초]영상편집, 4시간으로 프리미어 깨부시기!','10대부터 60대분까지, 학생,취준생,회사원,엔터,기자,선생님,목사님,학원강사,예비유투버 등 다양한 분야의 사람들이 절 믿고 제 수업을 선택하셨습니다.\r\n나이무관, 경력무관! 제 수업만 들으시면 여러분들도 영상인이 될 수 있습니다!','20201229134725_프리미어.PNG','인천광역시 남동구 서창남순환로 9 (서창동, 이편한세상서창)',10,10,'2020-12-24','2020-12-31','2020-12-29 13:59:18','test1','2020-12-30'),(37,'[KPOP] 에스파 ‘Black Mamba’ 일절 하루만에 마스터하고 영상 남기자!!+보아','*일절 완벽하게 2주만에 끝내고 3주에 영상 찍는 반 입니다.\r\n인스타에 올리고 싶으신 분!\r\n완벽한 춤과, 멋진 의상으로 영상 남기고 싶으신 분 신청 부탁 드립니다!\r\n요일은 세분 모집 되면 조율 할 예정.','20201229135931_kpop.PNG','서울특별시 구로구 연동로 168-19 (항동)',10,10,'2020-12-27','2021-01-04','2020-12-29 13:59:31','test1','2021-01-03'),(42,'sample','sample12341234','20201224172620_intro_symbol.jpg','서울특별시 강동구 천중로 64 (천호동)',12,12,'2020-12-24','2020-12-26','2020-12-24 17:26:20','test1','2020-12-25'),(43,'하루만에 쉽고 재밌게 배우는 댄스!! BTS,트와이스,NCT','추천\r\n1. 평소에 K-POP 댄스를 배워보고 싶었던 분\r\n2. 춤 춰본적이 없지만 한 번 도전해보고 싶은 분\r\n3. 취미로 춤 추면서 다이어트도 하고 싶은 분\r\n4. 여자춤을 배워보고 싶은 남자분 (여자멘토에게 배우기는 조금 부끄럽다 하시는 분)','20201229134619_강의.PNG','서울특별시 마포구 동교로 217 (동교동)',10,10,'2020-12-28','2021-01-04','2020-12-29 16:00:36','limtest','2021-01-20');
/*!40000 ALTER TABLE `offline_lecture` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-19 16:43:02
